from typing_extensions import Self


class privatc:
    x=10
    y=11

    def display(Self):
        print(Self.x+Self.y)

# d=privatc()
# d.display()